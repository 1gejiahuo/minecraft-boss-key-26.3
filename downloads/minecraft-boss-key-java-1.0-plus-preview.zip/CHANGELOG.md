# Changelog

## 0.5.0-preview — 2026-10-27

- Added Forge 1.20.1 and NeoForge 1.21.1 entrypoint JARs.
- Kept all loader JARs version-specific; other versions use the standalone Windows app.
- Runtime checks in the game are still pending.

## 0.4.0-preview — 2026-10-26

- Built separate NeoForge 26.3 and Forge 1.12.2 entrypoint JARs with the bundled Windows helper.
- Documented Quilt as a candidate for loading the Fabric universal JAR.
- Loader game runtime checks remain pending.

## 0.3.0-preview — 2026-10-26

- Added a Java 8 bytecode Fabric entrypoint for Fabric-supported versions. It launches the bundled Windows helper with the game process ID.
- Added process-targeted window selection and automatic helper exit after the game process ends.
- Kept the 26.3 native Fabric mod as a separate option.
- Cross-version game runtime tests are still pending.

## 0.2.0-preview — 2026-10-26

- Extended the Windows application to target Minecraft Java Edition releases from 1.0 onward, including April Fools builds, without game-version-specific code.
- Added foreground Java window matching for builds whose window title does not contain Minecraft.
- Added editable process names, title keywords, and foreground matching in `BossKey.ini`.
- Added a window matching smoke check. Individual game versions and fullscreen modes remain unverified.

## 0.1.0-preview — 2026-10-26

- Added a Fabric client mod for Minecraft Java 26.3.
- Added a standalone Windows background application.
- Added Ctrl+Shift+C global hide/restore and audio handling.
- Added Ctrl+Shift+X safe exit to the standalone application.
- Added editable hotkey configuration for both implementations.
- Confirmed both builds compile. In-game behavior remains unverified.

